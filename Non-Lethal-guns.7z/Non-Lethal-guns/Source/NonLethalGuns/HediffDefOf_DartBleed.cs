﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;
using RimWorld;
using UnityEngine;

namespace NonLethalGuns
{
    public static class HediffDefOf_DartBleed
    {
        public static HediffDef DartBleed;
    }
}
